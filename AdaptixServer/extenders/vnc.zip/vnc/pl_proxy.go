package main

import (
	"bufio"
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"net"
	"net/http"
	"time"
)

func handleStream(w http.ResponseWriter, r *http.Request) {
	sessionId := r.URL.Query().Get("session")
	if sessionId == "" {
		http.Error(w, "session parameter required", 400)
		return
	}

	session, err := getSession(sessionId)
	if err != nil {
		http.Error(w, err.Error(), 404)
		return
	}

	targetAddr := fmt.Sprintf("%s:%d", Config.BindHost, session.LocalPort)

	dialer := net.Dialer{Timeout: 5 * time.Second}
	conn, err := dialer.Dial("tcp", targetAddr)
	if err != nil {
		fmt.Printf("[VNC] Stream proxy: failed to connect to %s: %v\n", targetAddr, err)
		http.Error(w, "Failed to connect to VNC stream", 502)
		return
	}
	defer conn.Close()

	req, _ := http.NewRequest("GET", "/stream", nil)
	if err := req.Write(conn); err != nil {
		fmt.Printf("[VNC] Stream proxy: failed to write request: %v\n", err)
		http.Error(w, "Failed to send request", 502)
		return
	}

	resp, err := http.ReadResponse(bufio.NewReader(conn), req)
	if err != nil {
		fmt.Printf("[VNC] Stream proxy: failed to read response: %v\n", err)
		http.Error(w, "Failed to read response", 502)
		return
	}

	for k, vv := range resp.Header {
		for _, v := range vv {
			w.Header().Add(k, v)
		}
	}
	w.WriteHeader(resp.StatusCode)

	buf := make([]byte, 32768)
	flusher, canFlush := w.(http.Flusher)
	for {
		n, err := resp.Body.Read(buf)
		if n > 0 {
			if _, werr := w.Write(buf[:n]); werr != nil {
				return
			}
			if canFlush {
				flusher.Flush()
			}
		}
		if err != nil {
			return
		}
	}
}

func handleInput(w http.ResponseWriter, r *http.Request) {
	sessionId := r.URL.Query().Get("session")
	if sessionId == "" {
		http.Error(w, "session parameter required", 400)
		return
	}

	session, err := getSession(sessionId)
	if err != nil {
		http.Error(w, err.Error(), 404)
		return
	}

	body, err := io.ReadAll(r.Body)
	if err != nil {
		http.Error(w, "Failed to read body", 400)
		return
	}

	var input struct {
		Type string          `json:"type"`
		Data json.RawMessage `json:"data"`
	}
	if err := json.Unmarshal(body, &input); err != nil {
		http.Error(w, "Invalid JSON", 400)
		return
	}

	var endpoint string
	switch input.Type {
	case "mouse":
		endpoint = "/mouse"
	case "keyboard":
		endpoint = "/keyboard"
	default:
		http.Error(w, "Invalid input type", 400)
		return
	}

	targetAddr := fmt.Sprintf("%s:%d", Config.BindHost, session.LocalPort)

	client := &http.Client{
		Timeout: 5 * time.Second,
	}

	targetURL := fmt.Sprintf("http://%s%s", targetAddr, endpoint)
	resp, err := client.Post(targetURL, "application/json", bytes.NewReader(body))
	if err != nil {
		fmt.Printf("[VNC] Input proxy: failed to forward to %s: %v\n", targetURL, err)
		http.Error(w, "Failed to forward input", 502)
		return
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(resp.StatusCode)
	w.Write(respBody)
}

func forwardToTarget(session *VncSession, method string, path string, body []byte) error {
	targetAddr := fmt.Sprintf("%s:%d", Config.BindHost, session.LocalPort)
	url := fmt.Sprintf("http://%s%s", targetAddr, path)

	client := &http.Client{Timeout: 5 * time.Second}

	var reqBody io.Reader
	if body != nil {
		reqBody = bytes.NewReader(body)
	}

	req, err := http.NewRequest(method, url, reqBody)
	if err != nil {
		return err
	}

	resp, err := client.Do(req)
	if err != nil {
		return err
	}
	resp.Body.Close()
	return nil
}
