@echo off
set PORT=%1
if "%PORT%"=="" set PORT=5900
cd /d "%~dp0"
start "" "%~dp0winvnc.exe" -run -rfbport %PORT% -localhost -SecurityTypes None
