@echo off
set PORT=%1
if "%PORT%"=="" set PORT=5900
cd /d "%~dp0"
set LOG=%TEMP%\adaptix_winvnc_%PORT%.log
echo [adaptix-vnc] dir=%CD% port=%PORT% > "%LOG%"
(
    echo [ultravnc]
    echo passwd=
    echo passwd2=
    echo [admin]
    echo AuthRequired=0
    echo SocketConnect=1
    echo AutoPortSelect=0
    echo PortNumber=%PORT%
    echo HTTPConnect=0
    echo AllowLoopback=1
    echo LoopbackOnly=1
    echo Loopback=1
    echo InputsEnabled=1
    echo QueryIfNoLogon=0
    echo QuerySetting=2
) > "%~dp0ultravnc.ini"

echo [adaptix-vnc] starting UltraVNC winvnc >> "%LOG%"
"%~dp0winvnc.exe" -kill >nul 2>nul
start "" /D "%~dp0" "%~dp0winvnc.exe" -multi -run

for /L %%I in (1,1,30) do (
    powershell -NoProfile -ExecutionPolicy Bypass -Command "$c=New-Object Net.Sockets.TcpClient; try { $c.Connect('127.0.0.1', %PORT%); $c.Close(); exit 0 } catch { exit 1 }" >nul 2>nul
    if not errorlevel 1 (
        echo [adaptix-vnc] listening on 127.0.0.1:%PORT%
        type "%LOG%"
        exit /b 0
    )
    timeout /t 1 /nobreak >nul
)

echo [adaptix-vnc] ERROR: winvnc did not listen on 127.0.0.1:%PORT%
tasklist /FI "IMAGENAME eq winvnc.exe"
type "%LOG%"
exit /b 1
